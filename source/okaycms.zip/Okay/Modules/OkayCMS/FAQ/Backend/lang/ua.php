<?php

$lang['left_faq_title'] = 'FAQ';
$lang['faq_title'] = 'FAQ';
$lang['faq_add'] = 'Додати FAQ';
$lang['no_faqs'] = 'Немає записів';
$lang['faq_added'] = 'FAQ добавлен';
$lang['faq_updated'] = 'FAQ доданий';
$lang['faq_answer'] = 'Відповідь';
$lang['faq_question'] = 'Питання';