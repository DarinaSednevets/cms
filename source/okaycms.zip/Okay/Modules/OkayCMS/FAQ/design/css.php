<?php

use Okay\Core\TemplateConfig\Css;

return [
    (new Css('faq.css')),
];

