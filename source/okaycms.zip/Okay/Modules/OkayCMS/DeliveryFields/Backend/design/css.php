<?php

use Okay\Core\TemplateConfig\Css;

return [
    (new Css('delivery_field.css')),
];