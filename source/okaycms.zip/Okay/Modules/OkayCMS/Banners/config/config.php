;<? exit(); ?>

;Изображения баннеров
banners_images_dir = files/originals/slides/
resized_banners_images_dir = files/resized/slides/

banners_hide_self_url = true