<?php

$lang['okay_cms__fast_order__title'] = 'Fast order';
$lang['okay_cms__fast_order__code'] = 'Code';
$lang['okay_cms__fast_order__description'] = "After installing the module in the panel, you should add the code indicated under the description in the subject of your project next to the button for adding goods to the basket. This must be done in the list of goods, as well as on the product card page.";
$lang['okay_cms__fast_order__captcha'] = "In quick order";
