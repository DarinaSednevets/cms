<?php

$lang['fast_order'] = "Быстрый заказ";
$lang['okay_cms__fast_order__form_required_error'] = 'Обязательное поле';
$lang['okay_cms__fast_order__form_name_error'] = 'Введите имя';
$lang['okay_cms__fast_order__form_phone_error'] = 'Введите номер телефона';
$lang['okay_cms__fast_order__order_submit'] = 'Заказать';
$lang['okay_cms__fast_order__form_captcha_error'] = 'Неверно введена капча';
$lang['okay_cms__fast_order__wrong_variant'] = 'Выбранный товар не найден';
