<?php

$lang['fast_order'] = "Fast Order";
$lang['okay_cms__fast_order__form_required_error'] = 'Required field';
$lang['okay_cms__fast_order__form_name_error'] = 'Enter your name';
$lang['okay_cms__fast_order__form_phone_error'] = 'Incorrect phone number';
$lang['okay_cms__fast_order__order_submit'] = 'Order';
$lang['okay_cms__fast_order__form_captcha_error'] = 'Captcha entered incorrectly';
$lang['okay_cms__fast_order__wrong_variant'] = 'Selected product not found';
