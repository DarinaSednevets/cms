<?php


namespace Okay\Core\TplMod\Nodes;


class SmartyCommentNode extends BaseNode
{
    
}