<?php


namespace Okay\Core\TplMod\Nodes;


class HtmlNode extends BaseNode
{
}