<?php


namespace Okay\Core\TplMod\Nodes;


class SmartyForeachNode extends BaseNode
{
    
}