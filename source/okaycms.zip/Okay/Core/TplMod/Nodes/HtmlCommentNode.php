<?php


namespace Okay\Core\TplMod\Nodes;


class HtmlCommentNode extends BaseNode
{
    
}