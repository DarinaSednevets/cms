<?php


namespace Okay\Core\TplMod\Nodes;


class SmartyFunctionNode extends BaseNode
{
    
}