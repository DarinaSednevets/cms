<?php


namespace Okay\Core\SmartyPlugins;


class Func extends Plugin {}
